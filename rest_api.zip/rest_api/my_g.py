def f():
    return 42


def g(x):
    return f()*x
